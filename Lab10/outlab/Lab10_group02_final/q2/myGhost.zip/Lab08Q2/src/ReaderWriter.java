import myLibrary.Book;
import myLibrary.Reader;
import myLibrary.Writer;

public class ReaderWriter {

    public static void main(String[] args) {

        Book sharedBuffer = new Book();

        Reader[] ob = new Reader[20];  
        for (int i=0; i<=19; i++) {
            ob[i] = new Reader(1,sharedBuffer);
            ob[i].k = i+1;
            new Thread(ob[i]).start();   
        }
        new Thread(new Writer(2000, sharedBuffer)).start();

    }
}
