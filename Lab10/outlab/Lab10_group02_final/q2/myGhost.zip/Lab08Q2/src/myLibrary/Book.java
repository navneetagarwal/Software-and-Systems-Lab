package myLibrary;
import java.util.*;

public class Book {

    public static int a = 0;

    private static final Object writeLock = new Object();

    private static final Object readWriteLock = new Object();

    private int numberReaders = 0;

    private int numberWriters = 0;

    private int numberWriteRequests = 0;

    public void write() throws InterruptedException {

        numberWriteRequests = 1;

        synchronized (readWriteLock) {
            while (numberReaders > 0) {
                readWriteLock.wait();
            }
        }

        synchronized (writeLock) {

            numberWriteRequests = 0;

            numberWriters = 1;

            System.out.println("Writer started writing.");
            Thread.sleep(10000);
            a++;
            System.out.println("Writer finished writing.");

            numberWriters = 0;

            synchronized (readWriteLock) {
                readWriteLock.notifyAll();
            }
        }
    }

    public void read(int c) throws InterruptedException {

        int k;
        k = c;

        Random randomGenerator = new Random();
        int randomInt = randomGenerator.nextInt(3001);
        
        synchronized (readWriteLock) {

            while (numberWriters > 0 || numberWriteRequests > 0) {
                readWriteLock.wait();
            }
        }

        numberReaders++;
        try {
            Thread.sleep(randomInt);
        }
        catch(InterruptedException e) {}

        System.out.println("Reader " + k + " started reading version " + a);
        Thread.sleep(5000);
        System.out.println("Reader " + k + " finished reading version " + a);

        numberReaders--;

        synchronized (readWriteLock) {
            readWriteLock.notifyAll();
        }
    }
}
