package myLibrary;

public class Writer implements Runnable {

    private final Book buffer;

    private int priority;

    public static boolean checkW = true;

    public Writer(int priority, Book buffer) {
        this.priority = priority;
        this.buffer = buffer;
    }

    @Override
    public void run() {
        for (int b = 1;b<=5;b++) {
            try {
                Thread.sleep(priority);
                buffer.write();
            } catch (InterruptedException e) {
            }
        }
        checkW = false;
    }
}
