package myLibrary;

public class Reader implements Runnable {

    private final Book buffer;

    private int priority;

    public int k;

    public Reader(int priority, Book buffer) {
        this.priority = 0;
        this.buffer = buffer;
    }

    @Override
    public void run() {
        while (Writer.checkW) {
            try {
                Thread.sleep(priority);
                buffer.read(k);
            } catch (InterruptedException e) {
            }
        }
    }
}
