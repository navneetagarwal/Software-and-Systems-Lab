import java.awt.*;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.event.*;  

public class SimpleGui implements ActionListener{
	private JFrame mainFrame;
	private JLabel headerLabel;
	private JLabel statusLabel;
	private JPanel controlPanel;
	private JTextArea area; 
	private JButton b,b1,b2,b3;
	String response;

	public SimpleGui(){
		
		mainFrame = new JFrame();
		headerLabel = new JLabel("",JLabel.CENTER);
		controlPanel = new JPanel();
		controlPanel.setLayout(null);
		mainFrame.setSize(500,500);  
		
//		mainFrame.setLayout(null);  
		controlPanel.setSize(500,500);
		headerLabel.setBounds(150, 100, 200, 30);
		mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  

	    
		
	    headerLabel.setText("Choose favourite colour"); 
	    controlPanel.add(headerLabel);
		b=new JButton("Blue");  
		b.setBounds(50,160,80, 30);  
		b.addActionListener(this);
		
		controlPanel.add(b);
		
		b1=new JButton("Red");  
		b1.setBounds(150,160,80, 30);
		b1.addActionListener(this);
		controlPanel.add(b1);
		
		b2=new JButton("Yellow");  
		b2.setBounds(250,160,80, 30);  
		b2.addActionListener(this);      
		controlPanel.add(b2);
		
		b3=new JButton("Close");  
		b3.setBounds(350,160,80, 30);  
		b3.addActionListener(this);      
		controlPanel.add(b3);
		
		
		
		mainFrame.setVisible(true);
		
		mainFrame.add(controlPanel);
			
		controlPanel.setVisible(false);
		response = JOptionPane.showInputDialog(null, "What is your name?", "Enter your name", JOptionPane.QUESTION_MESSAGE);
		controlPanel.setVisible(true);
			
				
		
	}

	public static void main(String[] args){
		SimpleGui bg = new SimpleGui();
	
	}
	public void actionPerformed(ActionEvent e) {
		Object src = e.getSource();
		if(src==b)
		JOptionPane.showMessageDialog(mainFrame, "Hey "+ response +" !! Your favourite colour is blue !!");
		else if(src==b1){
			JOptionPane.showMessageDialog(mainFrame, "Hey "+ response +" !! Your favourite colour is red !!");
		}
		else if(src==b2)
			JOptionPane.showMessageDialog(mainFrame, "Hey "+ response +" !! Your favourite colour is yellow !!");
		else{
			JOptionPane.showMessageDialog(mainFrame, "Hey "+ response +" !! Good Bye !!");
			mainFrame.dispose();
		}
	}

//	public class TArea {   
//	      
//	    TArea(){  
//	    f=new JFrame();
//	    new ImageIcon("b.jpg")
//	    area=new JTextArea(200,20);  
//	    area.setBounds(50,40,200,20);  
//	      
//	    area.setBackground(Color.white);  
//	    area.setForeground(Color.black);  
//	          
//	    f.add(area);  
//	      
//	    f.setSize(300,100);  
//	    f.setLayout(null);  
//	    f.setVisible(true);  
//	}  
//	}
}
	    
//	private void prepareGUI(){
//		
//		mainFrame = new JFrame("Java SWING Examples");
//		mainFrame.setSize(400,400);
//		mainFrame.setLayout(new GridLayout(3, 1));
//		headerLabel = new JLabel("",JLabel.CENTER);
//		statusLabel = new JLabel("",JLabel.CENTER);
//		controlPanel = new JPanel();
//
//		statusLabel.setSize(350,100);
//		mainFrame.addWindowListener(new WindowAdapter() {
//			public void windowClosing(WindowEvent windowEvent){
//				System.exit(0);
//			}        
//		});    
//
//		
//		headerLabel.setText("I am a basic GUI!!"); 
//		mainFrame.add(headerLabel);
//		mainFrame.add(controlPanel);
//		mainFrame.add(statusLabel);
//		mainFrame.setVisible(true);  
//	}
